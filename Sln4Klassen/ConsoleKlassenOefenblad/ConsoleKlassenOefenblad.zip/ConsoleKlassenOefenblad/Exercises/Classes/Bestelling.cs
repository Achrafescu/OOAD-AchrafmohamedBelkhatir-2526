﻿namespace ConsoleKlassenOefenblad.Exercises.Classes;

internal class Bestelling
{
    // Properties
    public int BestellingId { get; set; }
    public DateTime Datum { get; set; } = DateTime.Now;
    public string KlantNaam { get; set; }
    public string Status
    {
        get;
        set
        {
            string[] toegelaten = { "Bezig", "Afgerond", "Geannuleerd" };
            if (!toegelaten.Contains(value)) throw new ArgumentException($"Ongeldige status: {value}");
            field = value;
        }
    } = "Bezig";

    // Berekende properties
    public decimal TotaalBedrag 
    {
        get 
        {
            return 0; // verwijder deze regel en implementeer deze property
            // ...
        }
    }

    // ToString override
    public override string ToString()
    {
        // pas dit aan zodat het aantal producten weergegeven wordt
        return $"#{BestellingId} — {KlantNaam} | 0 product(en) | € {TotaalBedrag:F2} | {Status}";
    }
}
